﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CadastroPonto.Migrations
{
    public partial class CriarBanco : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Funcionarios",
                columns: table => new
                {
                    Matricula = table.Column<int>(type: "int", nullable: false),
                    Nome = table.Column<string>(type: "text", nullable: false),
                    Sexo = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: true),
                    PIS = table.Column<double>(type: "double", nullable: false),
                    CPF = table.Column<double>(type: "double", nullable: false),
                    Salario = table.Column<short>(type: "smallint", nullable: false),
                    E_mail = table.Column<string>(type: "text", nullable: true),
                    AdmissaoData = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Funcionarios");
        }
    }
}
