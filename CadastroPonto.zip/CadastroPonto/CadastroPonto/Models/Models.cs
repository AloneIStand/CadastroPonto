﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;

namespace CadastroPonto.Models
{
    [Keyless]
    public class Funcionario
    {
        public int Matricula { get; set; }
        
        [Required(ErrorMessage = "O campo nome é obrigatório")]
        public string Nome { get; set; }

        [StringLength(1, ErrorMessage = "Coloque apenas F ou M no campo Sexo")]
        public string Sexo { get; set; }

        [Required(ErrorMessage = "O campo PIS é obrigatório")]
        public double PIS { get; set; }

        [Required(ErrorMessage = "O campo CPF é obrigatório")]
        public double CPF { get; set; }

        [Required(ErrorMessage = "O campo Salario é obrigatório")]
        public short Salario { get; set; }

        public string E_mail { get; set; }

        [Required(ErrorMessage = "O campo Data de admissão é obrigatório")]
        public DateTime AdmissaoData { get; set; }

    }
}
