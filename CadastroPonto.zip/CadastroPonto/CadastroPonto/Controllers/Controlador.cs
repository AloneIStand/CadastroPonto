﻿using CadastroPonto.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CadastroPonto.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ControladorCadastro : ControllerBase
    {
        private static List<Funcionario> funcionarios = new List<Funcionario>();
        private static int Matricula = 1;

        [HttpPost]
        public IActionResult AdicionarFuncionario([FromBody] Funcionario funcionario)
        {
            funcionario.Matricula = Matricula++;
            funcionarios.Add(funcionario);
            return CreatedAtAction(nameof(RecuperarCadastro), new { Matricula = funcionario.Matricula }, funcionario);
        }

        [HttpGet]
        public IActionResult RecuperarCadastro()
        {
            return Ok(funcionarios);
        }

        [HttpGet("{matricula}")]
        public IActionResult RecuperarCadastro(int matricula)
        {
            Funcionario funcionario = funcionarios.FirstOrDefault(funcionario => funcionario.Matricula == matricula);
            if(funcionario != null)
            {
                return Ok(funcionario);
            }
            return NotFound();
        }
    }
}
