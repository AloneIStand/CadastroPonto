﻿using CadastroPonto.Models;
using Microsoft.EntityFrameworkCore;

namespace CadastroPonto.Data
{
    public class Cadastrocontext : DbContext
    {
        public Cadastrocontext(DbContextOptions<Cadastrocontext> opt) : base(opt)
        {

        }

        public DbSet<Funcionario> Funcionarios { get; set; }

    }
}