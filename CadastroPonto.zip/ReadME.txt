Olá recrutador,
Usei o Postman ou o Swagger em conjunto para fazer as requisições/cadastros, pra facilitar vou deixar o script da requisição de como Cadastrar funcionário.

Script de Cadastro:
{
  "matricula": 0,
  "nome": "string",
  "sexo": "string",
  "pis": 0,
  "cpf": 0,
  "salario": 0,
  "e_mail": "string",
  "admissaoData": "2022-07-04T13:25:41.730Z"
}
A matricula de cada funcionário é gerada no momento em que ele é cadastrado, a forma de recuperar e consultar o cadastro é também pelo Postman ou o Swagger.

No caso, C# é uma linguagem nova pra mim, por conta disso tive dificuldades, código integrado ao banco de dados porém o código dele está junto ao Código Principal, vou fazer só um upload ao Git.
Atentar-se ao String Connection, a senha que coloquei é do MySQL no meu PC, provavelmente para rodar o código em outra maquina será necessário fazer a Migração ao banco novamente.

Migration concluída para mostrar os códigos do banco de dados.
